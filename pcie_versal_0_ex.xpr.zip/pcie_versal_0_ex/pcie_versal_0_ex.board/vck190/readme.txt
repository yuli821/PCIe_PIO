Validate that part xcvc1902-vsva2197-2MP-e-S is available in your Vivado installation.  
Please see details in the board lounge or in user guide UG973: Vivado Release Notes, Installation, and Licensing.

For more information please refer to user guide UG994: Using the Platform Board Flow in IP Integrator.
